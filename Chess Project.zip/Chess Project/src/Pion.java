//import com.modeliosoft.modelio.javadesigner.annotations.objid;

//@objid ("f4992e68-6f26-4043-94dc-99f1f75bf5a3")
public class Pion extends Piece {
	public Pion() {
		super();
	}
	public Pion(int colonne, int ligne, int couleur) {
		super(colonne, ligne, couleur);
	}
	public boolean mouvementValide(int colonne, int ligne) {
		return true;
	}
}
