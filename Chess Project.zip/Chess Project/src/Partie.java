//import com.modeliosoft.modelio.javadesigner.annotations.objid;

//@objid ("acdd2e2b-42a6-456a-89a7-a2eabb71f387")
public class Partie {
    //@objid ("c4ccff15-8986-4e04-9816-74beaaf9eea6")
    public Joueur[] joueurs;

    //@objid ("be05b0af-2dbf-43e1-8336-e31057ec44e4")
    private Plateau plateau;
    public Partie() {
    }
    public Partie(String pseudo1, String pseudo2) {
    	this.joueurs = new Joueur[2];
    	this.joueurs[0] = new Joueur(pseudo1, 0);
    	this.joueurs[1] = new Joueur(pseudo2, 1);
    	this.plateau =  new Plateau();
    }

}
