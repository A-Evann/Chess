public class Joueur {
    //@mdl.prop
    //@objid ("f6bfd73a-9d30-41f4-a312-5b16608ed460")
    private String Pseudo;
    //@mdl.prop
    //@objid ("87f98d04-28cb-40d2-8218-e6bd28f1f2b0")
    private int Couleur;
    
    public Joueur() {}
    public Joueur(String pseudo, int couleur) {
    	this.Pseudo = pseudo;
    	this.Couleur = couleur;
    }
    //@mdl.propgetter
    public String getPseudo() {
        // Automatically generated method. Please do not modify this code.
        return this.Pseudo;
    }

    //@mdl.propsetter
    public void setPseudo(String value) {
        // Automatically generated method. Please do not modify this code.
        this.Pseudo = value;
    }

    //@mdl.propgetter
    public int getCouleur() {
        // Automatically generated method. Please do not modify this code.
        return this.Couleur;
    }

    //@mdl.propsetter
    public void setCouleur(int value) {
        // Automatically generated method. Please do not modify this code.
        this.Couleur = value;
    }

}
