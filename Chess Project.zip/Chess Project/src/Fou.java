//import com.modeliosoft.modelio.javadesigner.annotations.objid;

//@objid ("06839443-b2a6-4694-a26f-4ef455d47ea0")
public class Fou extends Piece {
	public Fou() {
		super();
	}
	public Fou(int colonne, int ligne, int couleur) {
		super(colonne, ligne, couleur);
	}
	public boolean mouvementValide(int colonne, int ligne) {
		return true;
	}
}
