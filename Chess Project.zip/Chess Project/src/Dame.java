//import com.modeliosoft.modelio.javadesigner.annotations.objid;

//@objid ("0b88675f-db7d-47be-8045-76394f23c8dd")
public class Dame extends Piece {
	public Dame() {
		super();
	}
	public Dame(int colonne, int ligne, int couleur) {
		super(colonne, ligne, couleur);
	}
	public boolean mouvementValide(int colonne, int ligne) {
		return true;
	}
}
