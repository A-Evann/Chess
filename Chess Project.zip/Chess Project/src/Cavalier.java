//import com.modeliosoft.modelio.javadesigner.annotations.objid;

//@objid ("1266c400-5b38-486d-9738-abf84790518f")
public class Cavalier extends Piece {
	public Cavalier() {
		super();
	}
	public Cavalier(int colonne, int ligne, int couleur) {
		super(colonne, ligne, couleur);
	}
	public boolean mouvementValide(int colonne, int ligne) {
		return true;
	}
}
