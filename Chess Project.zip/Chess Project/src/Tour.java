//import com.modeliosoft.modelio.javadesigner.annotations.objid;

//@objid ("0732e3a5-8c3c-4d73-b798-187796caacb4")
public class Tour extends Piece {
	public Tour() {
		super();
	}
	public Tour(int colonne, int ligne, int couleur) {
		super(colonne, ligne, couleur);
	}
	public boolean mouvementValide(int colonne, int ligne) {
		return true;
	}
}
