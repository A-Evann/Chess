public class Plateau {
    public Piece[] plateau;

    public Plateau() {
    	this.plateau = new Piece[64];//nouveau tableau de 64 cases
    	//initialisation du plateau :
    	//les pions blancs
    	for(int i = 8; i < 16; i++) {
    		int ligne = i/8;
    		int colonne = i%8;
    		this.plateau[i] = new Pion(colonne, ligne, 0);
    	}
    	//les pions noirs
    	for(int i = 48; i < 56; i++) {
    		int ligne = i/8;
    		int colonne = i%8;
    		this.plateau[i] = new Pion(colonne, ligne, 1);
    	}
    	//tours
    	this.plateau[0] = new Tour(0,0,0);
    	this.plateau[7] = new Tour(7,0,0);
    	this.plateau[56] = new Tour(0,7,1);
    	this.plateau[63] = new Tour(7,7,1);
    	//cavaliers
    	this.plateau[1] = new Cavalier(1,0,0);
    	this.plateau[6] = new Cavalier(6,0,0);
    	this.plateau[57] = new Cavalier(1,7,1);
    	this.plateau[62] = new Cavalier(6,7,1);
    	//fous
    	this.plateau[2] = new Cavalier(2,0,0);
    	this.plateau[5] = new Cavalier(5,0,0);
    	this.plateau[58] = new Cavalier(2,7,1);
    	this.plateau[61] = new Cavalier(5,7,1);
    	//dames
    	this.plateau[3] = new Cavalier(3,0,0);
    	this.plateau[59] = new Cavalier(3,7,1);
    	//rois
    	this.plateau[4] = new Cavalier(4,0,0);
    	this.plateau[60] = new Cavalier(4,7,1);
    }

    public boolean caseLibre(int colonne, int ligne) {
    	int indice_case = (8 * ligne) + colonne;
    	return this.plateau[indice_case] == null;
    }
    public void bougerPiece(int colonne, int ligne, Piece p) {
    	int indice_case_arriv = (8 * ligne) + colonne;
    	int indice_case_dep = (8 * p.getLigne()) + p.getColonne();
    	this.plateau[indice_case_dep] = null;//la case ou etait la piece devient null
    	this.plateau[indice_case_arriv] = p;//la case ou elle bouge devient la piece
    	//on met a jour les coordonn�es de la piece
    	p.setColonne(colonne);
    	p.setLigne(ligne);
    }
    public void afficherPlateau() {
    	for(int i=0; i<64; i++) {
    		String aff="";
    		if(this.plateau[i] == null) {
    			aff = "_";
    		}
    		else {
    			aff = ""+ this.plateau[i].getCouleur();
    		}
    		System.out.print(aff +"\t");
    		if(i%8 == 7) {
    			System.out.println("");
    		}

    	}

    }

}
