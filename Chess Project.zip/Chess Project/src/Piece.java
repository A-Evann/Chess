//import com.modeliosoft.modelio.javadesigner.annotations.mdl;
//import com.modeliosoft.modelio.javadesigner.annotations.objid;

//@objid ("7fffc281-3b31-4905-a17d-855913beb849")
public abstract class Piece {
    private int ligne;
    private int colonne;
    private int couleur;//0=blanc, 1=noir ???? 
    
    public Piece() {};//constructeur vide
    public Piece(int colonne, int ligne, int couleur) {
    	this.ligne = ligne;
    	this.colonne = colonne;
    	this.couleur = couleur;
    }
    public int getLigne() {
        // Automatically generated method. Please do not modify this code.
        return this.ligne;
    }

    public void setLigne(int value) {
        // Automatically generated method. Please do not modify this code.
        this.ligne = value;
    }

    public int getColonne() {
        // Automatically generated method. Please do not modify this code.
        return this.colonne;
    }

    public void setColonne(int value) {
        // Automatically generated method. Please do not modify this code.
        this.colonne = value;
    }


    public int getCouleur() {
        // Automatically generated method. Please do not modify this code.
        return this.couleur;
    }
    public void setCouleur(int value) {
        // Automatically generated method. Please do not modify this code.
        this.couleur = value;
    }
    public boolean caseValide(int colonne, int ligne){
    	return (colonne>=0 && colonne<=7) && (ligne>=0 && ligne<=7);
    }
    public abstract boolean mouvementValide(int colonne, int ligne);

}
