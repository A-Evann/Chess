//import com.modeliosoft.modelio.javadesigner.annotations.objid;

//@objid ("4370dff4-e377-491f-a3f6-83c91a4d766e")
public class Roi extends Piece {
	public Roi() {
		super();
	}
	public Roi(int colonne, int ligne, int couleur) {
		super(colonne, ligne, couleur);
	}
	public boolean mouvementValide(int colonne, int ligne) {
		return true;
	}
}
