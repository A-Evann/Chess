
public class Main {
	public static void main(String[] args) {
		Plateau p = new Plateau();
		p.afficherPlateau();
	}
}
